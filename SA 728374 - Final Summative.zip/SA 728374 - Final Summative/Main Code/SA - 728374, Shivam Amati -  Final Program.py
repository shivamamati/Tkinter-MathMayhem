# Name: Shivam Amati, ID: 728374
# Description: Math Mayhem, a flashcard system has flashcards for people to improve their math skills including
#              addition, subtraction and multiplication and upto 4 levels. The user will first be welcomed, then sent to
#              settings tab to set their level and amount of questions they would like to have, andif they would like to have
#              Negative Numbers. They will then press start and the numbers will appear infront of them.

# +++++ Import ALL TKINTER LIBRARIES ++++++
from tkinter import *
from tkinter import ttk
from tkinter.ttk import Progressbar
from tkinter import messagebox
import random

# Initialize GLOBAL Variable for Functions and the Main Program
correct_count = 0
wrong_count = 0
total_count = 0
level = 1


############################################### FUNCTIONS ###########################################################

# Function for obtaining level of user's choice
def getlevel():

    # Initialize global variable and set as level
    global level

    # Recieve and set level variable with spin input for easy use in coming functions
    if int(spin_level.get()) == 1:
        level = 1
    elif int(spin_level.get()) == 2:
        level = 2
    elif int(spin_level.get()) == 3:
        level = 3
    elif int(spin_level.get()) == 4:
        level = 4

# Function that recieves the number of input the user wants
def get_questions():
    
    #Globalize variables 
    global numquestions, total_count

    #Recieves number that user inputted
    numquestions = spin_questions.get()

    #setting the number of question to the total count to check
    if numquestions == total_count:
        messagebox.showerror("title", "Done")


# Create a function for generating random numbers to use in the equations
def generate_question(level):

    # Set Global Variables
    global num1, num2, operator

    # Call level function
    getlevel()

    # Randomizes the number based on the user's preference of level
    if radio.get() == 1:
        if level == 1:
            num1 = random.randint(-3, 3)
            num2 = random.randint(-3, 3)
        elif level == 2:
            num1 = random.randint(-6, 6)
            num2 = random.randint(-6, 6)
        elif level == 3:
            num1 = random.randint(-9, 9)
            num2 = random.randint(-9, 9)
        elif level == 4:
            num1 = random.randint(-12, 12)
            num2 = random.randint(-12, 12)
    elif radio.get() == 2:
        if level == 1:
            num1 = random.randint(1, 3)
            num2 = random.randint(1, 3)
        elif level == 2:
            num1 = random.randint(1, 6)
            num2 = random.randint(1, 6)
        elif level == 3:
            num1 = random.randint(1, 9)
            num2 = random.randint(1, 9)
        elif level == 4:
            num1 = random.randint(1, 12)
            num2 = random.randint(1, 12)

    # Randomizes the Symbol for operator to use in the equation
    operator = random.choice(['+', '-', 'x'])


# Create a function for displaying the question and the values in the equation
def display_numbers():
    global num1, num2, operator, ans

    # call function to generate values
    generate_question(level)

    # Sets variable text in Label widget of that variable to the random numbers
    label_number1['text'] = num1
    label_number2['text'] = num2
    operator_label['text'] = operator

# Function to start the game
def start():
    global running
    asking = True
    # Call Level Function to generate values
    generate_question(level)
    get_questions()
    # Call display function to display the numbers
    display_numbers()

#Functin to check the answer
def check_answer():
    # globalizing variables
    global correct_count, wrong_count, total_count, num1, num2, invalid_label, numquestions, ans, right_answer

    # retrieving entered answer (invalid input checking included)
    try:
        ans = int(answer_entry.get())
    except:
        messagebox.showerror('ERROR', 'Please enter a valid Number')

    # determining correct answer for + operator
    if operator == "+":
        #Check if the right answer matches user input
        if num1 + num2 == ans:
            # Have a variable already stored as correct, and add to count and total count if correct
            right_answer = num1 + num2
            correct_count += 1
            questions_right_label.configure(text=correct_count)
            total_count += 1
            questions_total_label.configure(text=total_count)
            increase_bar()

        #Adds to count if the user input is wrong
        else:
            right_answer = num1 + num2
            wrong_count += 1
            questions_wrong_label.configure(text=wrong_count)
            total_count += 1
            questions_total_label.configure(text=total_count)
            increase_bar()
    #Checks to see if answer is right or wrong for subtraction operator
    elif operator == "-":
        #check to see if the user answer matches the right answer
        if num1 - num2 == ans:
            right_answer = num1 - num2
            # Add to all the counts and configure the label into the new score
            correct_count += 1
            questions_right_label.configure(text=correct_count)
            total_count += 1
            questions_total_label.configure(text=total_count)
            #increase Progress bar increment based on being closer to the end
            increase_bar()
        #Check to see if answer is wrong and update wrong and total scores
        else:
            #lists for right answer
            right_answer = num1 - num2
           # Add to counts
            wrong_count += 1
            questions_wrong_label.configure(text=wrong_count)
            total_count += 1
            questions_total_label.configure(text=total_count)
            # Increases progress bar increment
            increase_bar()
    # Checks to see if answer is correct for this operator
    elif operator == "x":
        if num1 * num2 == ans:
            # Adds to the counter and scores
            right_answer = num1 * num2
            correct_count += 1
            questions_right_label.configure(text=correct_count)
            total_count += 1
            questions_total_label.configure(text=total_count)
            #Increases Progressbar based on the increment change
            increase_bar()
        # Answer is wrong, and updates scores and configures
        else:
            # Adds to the wrong scores and total scores
            right_answer = num1 * num2
            wrong_count += 1
            questions_wrong_label.configure(text=wrong_count)
            total_count += 1
            questions_total_label.configure(text=total_count)
            increase_bar()
   # Tells program to display messagebox and end the game when the amount of questions user wants
    if total_count < int(spin_questions.get()):
        display_numbers()
    elif total_count == int(spin_questions.get()):
        end = messagebox.askretrycancel("Congrats, You're Finished",
                                        "Congrats, You're Finished, Press Retry to Play again or cancel to exit the application")
        # Selects the settings tab
        tab_control.select(tab2)

        #resets game if player wants to play again
        if end == True:
            reset()
        # closes GUI if player doesn't want to play the game
        elif end == False:
            window.destroy()
    #Deletes Entry box for user input after every answer
    answer_entry.delete(0, END)
    #Starts the game after recieving all important information
    start()

#Reset button if they would like to end the game
def reset():
    # Globalize variables for counters
    global correct_count, wrong_count, total_count, running

    # Setting counts to 0 to configure
    correct_count = 0
    wrong_count = 0
    total_count = 0

    #set progress bar to 0
    bar['value'] = 0

   # relabel the labels that the numbers sit on with a question mark
    label1_reset = '?'
    operator_reset = "?"
    label2_reset = "?"

    # Change the labels for the counts with 0
    questions_right_label.configure(text=correct_count)
    questions_wrong_label.configure(text=wrong_count)
    questions_total_label.configure(text=total_count)

    # Configure the labels back to default with question marks
    label_number1.configure(text=label1_reset)
    operator_label.configure(text=operator_reset)
    label_number2.configure(text=label2_reset)


# function to use enter as a button to enter input
def enter(enter):
    check_answer()

# Function that moves to the settings/levels tab
def levels_tab():
    tab_control.select(tab2)

# Function that moves to the main game tab
def play_tab():
    tab_control.select(tab3)

# Function for the Progress bar
def increase_bar():
    total_count = int(questions_total_label.cget('text'))

    increment = 100 / spin.get()
    bar["value"] += increment



################################## MAIN PROGRAM #################################################################

#Create Main Program and set Title
window = Tk()
window.title("Math Mayhem")

# Set the size requirements
window.geometry('1000x600')
window.configure(bg="red")

#Change the style for better access for users
style = ttk.Style()
style.theme_use("clam")

# +++++ Creating TABS ++++
tab_control = ttk.Notebook(window)

tab1 = Frame(tab_control)
tab2 = Frame(tab_control)
tab3 = Frame(tab_control)

#Setting name of tabs
tab_control.add(tab1, text='Welcome')
tab_control.add(tab2, text='Settings')
tab_control.add(tab3, text='Play')
tab_control.pack(expand=1, fill='both')


######################################################### WELCOME PAGE ################################################

# Adding First Image
image_1 = PhotoImage(file='math-mayhem.png')
lbl_image = Label(tab1, image=image_1, fg="red")
lbl_image.place(relx=0.75, rely=0.45, anchor=CENTER)

# Welcome Label
welcome_lbl = Label(tab1, text="MATH MAYHEM", font=("Times New Roman", 50), fg="Red")
welcome_lbl.place(relx=0.085, rely=0.10)

#Adding a Discription Label
description_lbl = Label(tab1, text="""
    Welcome to Math Mayhem, With our  Flashcards, 
    You will be able to Hone your Mathematical 
    Skills including Addition, Subtraction and 
    Multiplication! 
    """, font=("Times New Roman", 18))
description_lbl.place(relx=0.015, rely=0.42, anchor=W)

# Let user know to start the game with play button
lbl2 = Label(tab1, text="Click Play to Start", font=("Times New Roman", 18))
lbl2.place(relx=0.20, rely=0.60, anchor=W)

# Play button lets user enter the settings/levels tab and is used as a button
play_image = PhotoImage(file='playbutton.png')
play_bttn = Button(tab1, text="PLAY", font=("Ariel Bold", 18), bg="White", fg="Black", command=levels_tab)
play_bttn.place(relx=0.25, rely=0.75, anchor=SW)

##########################################  SETTINGS TAB ########################################################

#Creating main page title for settings tab
title_tab2 = Label(tab2, text="Settings", font=("Times New Roman", 60))
title_tab2.place(relx=0.20, rely=0.05)

# Creating Label for Instructions
levels_instructions = Label(tab2, text="""
Start off by choosing your levels and instructions

Level 1: Random Numbers from 1 - 3!
Level 2: Random Numbers from 1 - 6!
Level 3: Random Numbers from 1 - 9!
Level 4: Random Numbers from 1 - 12!

Pick the desired number of questions you
would like to have
""", font=("Times New Roman", 20))
levels_instructions.place(relx=0.05, rely=0.25)

######### SPIN BOX ###########

# Setting spin to 10 for proper division
spin = IntVar()
spin.set(10)

# Create a Label to let users know this spinbutton is for Levels
levels_label = Label(tab2, text="Level:", font=("Times New Roman", 25))
levels_label.place(relx=0.73, rely=0.33)

# Create a Label to let users know this spinbutton is for questions
questions_label = Label(tab2, text="# of Questions", font=("Times New Roman", 25))
questions_label.place(relx=0.73, rely=0.63)

# Actual spinbox with levels 1 - 4 as required
spin_level = Spinbox(tab2, from_=1, to=4, width=5, font=("Times New Roman", 40))
spin_level.place(relx=0.73, rely=0.42)

# Spinbox for questions to ask how many questions user wants
spin_questions = Spinbox(tab2, from_=10, to=1000, width=5, font=("Times New Roman", 50))
spin_questions.place(relx=0.73, rely=0.70)

# Play button to move users to main game page
play_bttn2 = Button(tab2, text="Confirm Settings", font=("Ariel Bold", 20), bg="White", fg="Black", command=play_tab)
play_bttn2.place(relx=0.72, rely=0.96, anchor=SW)

# Negative Numbers (ENHANCEMENT)

#Create radio buttons

# set radio to 2 to automatically say no to negative numbers unless user wants
radio = IntVar()
radio.set(2)

#create label to let user know radiobutton is for negative numbers
label_negative = Label(tab2, text="Include Negative:?", font=("Times New Roman", 30))
label_negative.place(relx=0.68, rely=0.10)

# yes radiobutton
rad_negative_yes = Radiobutton(tab2, text='Yes', font=("Times New Roman", 15), value=1, variable=radio)
rad_negative_yes.place(relx=0.75, rely=0.20)

# no radiobutton
rad_negative_no = Radiobutton(tab2, text='No', font=("Times New Roman", 15), value=2, variable=radio)
rad_negative_no.place(relx=0.75, rely=0.25)

##################################################### PLAY TAB ########################################################

#Setting a background
background = PhotoImage(file="Background.png")
bg_label = Label(tab3, image=background)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Importing an image as an equal sign
equalsign = PhotoImage(file="equal.png")
bg_label = Label(tab3, image=equalsign)
bg_label.place(relx=0.65, rely=0.35)


# Reset Button to reset scores and labels
reset_image = PhotoImage(file="Reset(22).png")
reset = Button(tab3, image=reset_image, command=reset)
reset.place(relx=0.78, rely=0.82)

# Change Levels Button to go back to settings
change_levels = Button(tab3, text="Change Levels", font=("Times New Roman", 17), command=levels_tab)
change_levels.place(relx=0.77, rely=0.73)

# Background Layout of First square
num1_square = PhotoImage(file="square.png")
background_for_equations = Label(tab3, image=num1_square)
background_for_equations.place(relx=0.025, rely=0.25)

# Background Layout of second square
operator_square = PhotoImage(file="square.png")
background_for_equations = Label(tab3, image=operator_square)
background_for_equations.place(relx=0.23, rely=0.25)

# Background Layout of third square
num2_square = PhotoImage(file="square.png")
background_for_equations = Label(tab3, image=operator_square)
background_for_equations.place(relx=0.45, rely=0.25)

# Background Layout of fourth square
answer_square = PhotoImage(file="square.png")
background_for_equations = Label(tab3, image=operator_square)
background_for_equations.place(relx=0.81, rely=0.25)

# number 1 label
label_number1 = Label(tab3, text='?', font=("Times New Roman", 90), bg='white', fg='red')
label_number1.place(relx=0.12, rely=0.42, anchor=CENTER)

# operator label
operator_label = Label(tab3, text="?", font=("Times New Roman", 90), bg='white', fg='red')
operator_label.place(relx=0.33, rely=0.42, anchor=CENTER)

# second number label
label_number2 = Label(tab3, text='?', font=("Times New Roman", 90), bg='white', fg='red')
label_number2.place(relx=0.55, rely=0.42, anchor=CENTER)

# Answer Entry
answer_entry = Entry(tab3, width=2, font=("Times New Roman", 90), background="white", foreground="red")
answer_entry.place(relx=0.83, rely=0.28)
answer_entry.focus()

# Start Button
start_button = Button(tab3, text="Press to Start", font=("Times New Roman", 20), fg="Black", bg="white", command=start,
                      background="white", foreground="red")
start_button.place(relx=0.13, rely=0.075, anchor=CENTER)


# Scores ( TEXT ONLY )
questions_right_label_text = Label(tab3, text=': correct ', font=("Times New Roman", 20), background="white",
                                   foreground='black')
questions_wrong_label_text = Label(tab3, text=': wrong ', font=("Times New Roman", 20), background="white",
                                   foreground='black')
questions_total_label_text = Label(tab3, text=': total questions ', font=("Times New Roman", 20), background="white",
                                   foreground='black')

questions_right_label_text.place(relx=0.07, rely=0.73)
questions_wrong_label_text.place(relx=0.07, rely=0.79)
questions_total_label_text.place(relx=0.07, rely=0.85)

# SCORES ( NUMBERS )
questions_right_label = Label(tab3, text='0', font=("Times New Roman", 20), background=
"white", foreground='black')
questions_wrong_label = Label(tab3, text='0', font=("Times New Roman", 20), background=
"white", foreground='black')
questions_total_label = Label(tab3, text='0', font=("Times New Roman", 20), background=
"white", foreground='black')

questions_right_label.place(relx=0.05, rely=0.73)
questions_wrong_label.place(relx=0.05, rely=0.79)
questions_total_label.place(relx=0.05, rely=0.85)

# Check Button to see if answer is correct
check_button = Button(tab3, text="Check Answer", font=("Times New Roman", 20), command=check_answer)
check_button.place(relx=0.790, rely=0.10)
enter = window.bind('<Return>', enter)

# Progress bar
style = ttk.Style()
style.theme_use("default")
style.configure("blue.Horizontal.TProgress", background="blue", foreground="blue")

bar = Progressbar(tab3, length=750, style="blue.Horizontal.TProgressbar")
bar["value"] = 0
bar.place(relx=0.12, rely=0.60)

################################ CODE IS FINISHED ##############################################################

# Running the main window
window.mainloop()



